let caminhaoLeiteiro = {
  x: 100,
  y: 250,
  velocidade: 2,
  carga: 0,
  maxCarga: 10,
  estado: "CARREGANDO"
};

let cidade = {
  leiteRecebido: 0,
  dinheiro: 100
};

let fazenda = {
  leiteDisponivel: 20,
  producaoDiaria: 5,
  vacas: []
};

function setup() {
  createCanvas(800, 400);
  textSize(16);
  
  // Cria 5 vacas (emojis) na fazenda
  for (let i = 0; i < 5; i++) {
    fazenda.vacas.push({
      x: random(50, 250),
      y: random(150, 350),
      tamanho: random(30, 50)
    });
  }
  
  createButton("Carregar Leite (10L)").position(50, 50).mousePressed(carregarLeite);
  createButton("Ordenhar Vacas (+5L)").position(50, 80).mousePressed(produzirLeite);
}

function draw() {
  background(240);
  
  // --- FAZENDA ---
  fill(160, 220, 160);
  rect(0, 0, 300, height);
  fill(0);
  textSize(20);
  text("FAZENDA DE LEITE 🐄", 50, 30);
  textSize(14);
  text(`Leite disponível: ${fazenda.leiteDisponivel}L`, 50, 120);
  
  // Desenha vacas emoji
  textSize(32);
  for (let vaca of fazenda.vacas) {
    text("🐄", vaca.x, vaca.y);
  }
  
  // Desenha celeiro
  fill(139, 69, 19);
  rect(200, 150, 80, 60);
  fill(255);
  textSize(14);
  text("Celeiro 🏠", 210, 180);
  
  // --- CIDADE ---
  fill(200, 200, 240);
  rect(500, 0, 300, height);
  fill(0);
  textSize(20);
  text("CIDADE 🏙️", 580, 30);
  textSize(14);
  text(`Leite recebido: ${cidade.leiteRecebido}L`, 520, 80);
  text(`Dinheiro: $${cidade.dinheiro}`, 520, 110);
  
  // Prédios com emojis
  desenharPredio(550, 150, 60, 120, "Mercado 🛒");
  desenharPredio(630, 120, 50, 150, "Laticínio 🥛");
  desenharPredio(700, 160, 40, 110, "Loja 🏪");
  
  // --- CAMINHÃO ---
  desenharCaminhaoLeiteiro();
  
  // Lógica do caminhão
  if (caminhaoLeiteiro.estado === "TRANSPORTANDO") {
    caminhaoLeiteiro.x += caminhaoLeiteiro.velocidade;
    if (caminhaoLeiteiro.x > 500) {
      caminhaoLeiteiro.estado = "DESCARREGANDO";
      setTimeout(descarregarLeite, 1500);
    }
  } else if (caminhaoLeiteiro.estado === "VOLTANDO") {
    caminhaoLeiteiro.x -= caminhaoLeiteiro.velocidade;
    if (caminhaoLeiteiro.x < 100) {
      caminhaoLeiteiro.estado = "CARREGANDO";
    }
  }
  
  // Carga
  fill(0);
  textSize(14);
  text(`Carga: ${caminhaoLeiteiro.carga}L/${caminhaoLeiteiro.maxCarga}L`, 
       caminhaoLeiteiro.x - 30, caminhaoLeiteiro.y - 30);
  
  // Garrafas de leite (emoji)
  if (caminhaoLeiteiro.carga > 0) {
    textSize(20);
    for (let i = 0; i < caminhaoLeiteiro.carga; i++) {
      text("🍼", caminhaoLeiteiro.x - 20 + i * 20, caminhaoLeiteiro.y);
    }
  }
}

function desenharPredio(x, y, largura, altura, nome) {
  fill(180);
  rect(x, y, largura, altura);
  // Janelas
  fill(255, 255, 150);
  for (let j = 0; j < 4; j++) {
    for (let i = 0; i < 3; i++) {
      rect(x + 10 + i * 15, y + 20 + j * 25, 8, 10);
    }
  }
  fill(0);
  textSize(14);
  text(nome, x + 5, y + altura + 15);
}

function desenharCaminhaoLeiteiro() {
  fill(255);
  rect(caminhaoLeiteiro.x - 40, caminhaoLeiteiro.y - 20, 80, 30);
  fill(200);
  rect(caminhaoLeiteiro.x - 10, caminhaoLeiteiro.y - 30, 30, 20);
  
  // Rodas
  fill(0);
  ellipse(caminhaoLeiteiro.x - 20, caminhaoLeiteiro.y + 10, 20, 20);
  ellipse(caminhaoLeiteiro.x + 20, caminhaoLeiteiro.y + 10, 20, 20);
  
  // Logo
  fill(0, 100, 255);
  textSize(12);
  text("LEITEIRO 🚛", caminhaoLeiteiro.x - 30, caminhaoLeiteiro.y);
}

function carregarLeite() {
  if (caminhaoLeiteiro.estado === "CARREGANDO" && fazenda.leiteDisponivel >= 10) {
    fazenda.leiteDisponivel -= 10;
    caminhaoLeiteiro.carga = 10;
    caminhaoLeiteiro.estado = "TRANSPORTANDO";
    
    // Animação das vacas
    for (let vaca of fazenda.vacas) {
      vaca.y += random(-5, 5);
    }
  }
}

function descarregarLeite() {
  if (caminhaoLeiteiro.estado === "DESCARREGANDO") {
    cidade.leiteRecebido += caminhaoLeiteiro.carga;
    cidade.dinheiro += caminhaoLeiteiro.carga * 2;
    caminhaoLeiteiro.carga = 0;
    caminhaoLeiteiro.estado = "VOLTANDO";
  }
}

function produzirLeite() {
  fazenda.leiteDisponivel += fazenda.producaoDiaria;
  // Piscada das vacas (mudança de emoji)
  for (let i = 0; i < fazenda.vacas.length; i++) {
    setTimeout(() => {
      let originalY = fazenda.vacas[i].y;
      fazenda.vacas[i].y = originalY + 5;
      setTimeout(() => { fazenda.vacas[i].y = originalY; }, 200);
    }, i * 100);
  }
}